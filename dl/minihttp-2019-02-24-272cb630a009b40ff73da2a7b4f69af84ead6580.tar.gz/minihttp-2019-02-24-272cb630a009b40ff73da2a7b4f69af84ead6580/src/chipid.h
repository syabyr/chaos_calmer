#pragma once

void chip_id();
void isp_version();
