#pragma once

int motion_detect_init();
int start();
int motion_detect_deinit();
