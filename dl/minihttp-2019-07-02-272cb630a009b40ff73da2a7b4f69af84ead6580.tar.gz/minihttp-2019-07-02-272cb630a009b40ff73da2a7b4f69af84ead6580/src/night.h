#pragma once
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>

bool night_mode_enable();

int32_t start_monitor_light_sensor();
