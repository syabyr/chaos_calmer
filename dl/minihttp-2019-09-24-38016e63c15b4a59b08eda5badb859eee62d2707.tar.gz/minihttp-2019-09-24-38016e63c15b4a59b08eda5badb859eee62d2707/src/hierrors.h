#pragma once

char * hi_errstr(int error);
