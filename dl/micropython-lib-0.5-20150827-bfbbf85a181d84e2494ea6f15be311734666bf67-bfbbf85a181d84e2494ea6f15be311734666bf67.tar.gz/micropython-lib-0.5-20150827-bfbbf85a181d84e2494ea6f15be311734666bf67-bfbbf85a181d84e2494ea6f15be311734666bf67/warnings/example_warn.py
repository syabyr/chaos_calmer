import warnings

warnings.warn('block_size of %d seems too small; using our '
                               'default of %d.',
                               RuntimeError, 2)
#                               RuntimeWarning, 2)
