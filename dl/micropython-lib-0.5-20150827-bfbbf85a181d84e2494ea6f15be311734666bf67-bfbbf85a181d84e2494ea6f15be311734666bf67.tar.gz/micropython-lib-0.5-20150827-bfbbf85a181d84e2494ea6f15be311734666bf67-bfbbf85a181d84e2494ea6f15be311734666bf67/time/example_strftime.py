import time

print(time.strftime("%Y-%m-%d %H:%M:%S"))
