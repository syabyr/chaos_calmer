def east_asian_width(c):
    return 1
