
#Little Wire Hardware Files

##Schematic

![sch](./Little-Wire_sch.png)

##Layout

![brd](./Little-Wire_brd.png)

##Note

I didn't had the littlewire.cc domain/website when I produced/designed this board, therefore schematic and board files are signed with my personal webpage which now redirects to the littlewire.cc

##Licence

This project is © ihsan Kehribar, and is published under the terms of the GNU General Public License, version 3 licence.
